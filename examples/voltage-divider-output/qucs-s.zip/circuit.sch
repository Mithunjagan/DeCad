<Qucs Schematic 26.1.1>
<Properties>
<View=0,0,1200,900,1,0,0>
<Grid=10,10,1>
<DataSet=circuit.dat>
<OpenDisplay=0>
<RunScript=0>
</Properties>
<Symbol>
</Symbol>
<Components>
<SPICE X1 1 300 215 -26 -60 0 0 "circuit.lib" 1 "_netn2,_netn3" 0 "no" 0 "none" 0 "" 0>
<GND * 1 300 245 0 0 0 0>
<.TR TR1 1 550 100 0 81 0 0 "lin" 1 "0" 1 "0.01" 1 "1001" 0 "Trapezoidal" 0 "2" 0 "1 ns" 0 "1e-16" 0 "150" 0 "0.001" 0 "1 pA" 0 "1 uV" 0 "26.85" 0 "1e-3" 0 "1e-6" 0 "1" 0 "CroutLU" 0 "no" 0 "yes" 0 "0" 0>
</Components>
<Wires>
<180 215 270 215 "n2" 180 195 0 "">
<330 215 420 215 "n3" 330 195 0 "">
</Wires>
<Diagrams>
</Diagrams>
<Paintings>
</Paintings>
