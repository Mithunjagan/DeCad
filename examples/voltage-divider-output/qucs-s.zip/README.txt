Application: Qucs-S
Open circuit.sch with Qucs-S. The SPICE wrapper exposes each node for plotting. Keep circuit.lib beside the schematic. Select ngspice as the simulator.
Component and pin mapping is in circuit.json. Unsupported device models are rejected.
