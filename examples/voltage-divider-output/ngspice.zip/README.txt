Application: ngspice
Open circuit.cir in the simulator.
Component and pin mapping is in circuit.json. Unsupported device models are rejected.
