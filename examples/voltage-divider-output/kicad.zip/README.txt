Application: KiCad
Open the native schematic files.
Component and pin mapping is in circuit.json. Unsupported device models are rejected.
