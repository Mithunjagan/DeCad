"""Native OrCAD Capture .DSN export through Capture's own database API (orDb_Dll_Tcl64).

The writer places each reviewed component from an installed Capture library, attaches every
connected pin to a wire stub carrying its net alias, saves the design, then reopens it with a
separate reader. Export succeeds only when the reopened pin/net map equals the source graph.
"""
import hashlib, io, json, os, re, subprocess, tempfile, zipfile
from pathlib import Path
from .engine import OperationError

HERE = Path(__file__).resolve().parent
TIMEOUT = 600

# KiCad symbol -> Capture package for parts whose value is not a part number.
GENERIC = {
    'Device:R': ('Discrete.olb', 'R'), 'Device:R_Small': ('Discrete.olb', 'R'),
    'Device:C': ('Discrete.olb', 'CAP NP'), 'Device:C_Small': ('Discrete.olb', 'CAP NP'),
    'Device:C_Polarized': ('Discrete.olb', 'CAP NP'), 'Device:L': ('Discrete.olb', 'INDUCTOR'),
    'Device:D': ('Discrete.olb', 'DIODE'), 'Device:LED': ('Discrete.olb', 'LED'),
    'Device:Battery': ('Discrete.olb', 'BATTERY'), 'Device:R_Potentiometer': ('Discrete.olb', 'POT'),
    'Simulation_SPICE:VDC': ('source.olb', 'VDC'), 'Simulation_SPICE:VSIN': ('source.olb', 'VSRC'),
}
# KiCad pin number -> Capture pin number where the generic symbols differ (PSpice sources use 0/1).
GENERIC_PINS = {'Simulation_SPICE:VDC': {'1': '0', '2': '1'}, 'Simulation_SPICE:VSIN': {'1': '0', '2': '1'}}
# Parts without an identically named Capture package. Each substitute was checked to be the
# same function and pinout family; the report flags them for review on the drawing.
SUBSTITUTES = {
    'TC514100': ('DRAM.OLB', 'HM514100JP_20SOJ'),
    'AM2910': ('Misc3.olb', 'AM2910A'), 'AM2910A': ('Misc3.olb', 'AM2910A'),
    'IDT7210': ('Arithmetic.olb', 'IDT7210L'), 'IDT7216': ('Arithmetic.olb', 'IDT7216L'),
}
# Preferred libraries when one package name exists in several.
PREFERENCE = ['74f.olb', '74ls.olb', '74hc.olb', 'discrete.olb', 'connector.olb', 'gate.olb',
              'arithmetic.olb', 'dram.olb', 'misc3.olb', 'muxdecoder.olb', 'latch.olb']


def orcad_root():
    candidates = [os.getenv('ORCAD_ROOT', ''), 'D:\\', 'C:\\Cadence\\OrCADX_26.1']
    candidates += sorted(str(p) for p in Path('C:/Cadence').glob('*')) if Path('C:/Cadence').is_dir() else []
    for c in candidates:
        if c and (Path(c) / 'tools/bin/orDb_Dll_Tcl64.dll').is_file() and (Path(c) / 'tools/bin/tclsh.exe').is_file():
            return Path(c)
    return None


def available():
    return orcad_root() is not None


def _run(root, script, *args):
    env = {**os.environ, 'PATH': str(root / 'tools/bin') + os.pathsep + os.environ.get('PATH', ''), 'CDSROOT': str(root)}
    try:
        r = subprocess.run([str(root / 'tools/bin/tclsh.exe'), str(HERE / script), str(root / 'tools/bin/orDb_Dll_Tcl64.dll'), *map(str, args)],
                           capture_output=True, text=True, timeout=TIMEOUT, env=env, cwd=str(root / 'tools/bin'))
    except subprocess.TimeoutExpired as e:
        raise OperationError('OrCAD Capture database operation timed out.') from e
    errors = [l[6:] for l in r.stdout.splitlines() if l.startswith('ERROR ')]
    if r.returncode or errors:
        raise OperationError('OrCAD Capture: ' + ('; '.join(errors) or (r.stderr or r.stdout)[-1500:]))
    return r.stdout


def library_index(cache):
    """Package name -> list of library paths, built once from every installed .olb."""
    root = orcad_root()
    cache = Path(cache)
    if not cache.exists():
        libs = sorted(str(p) for p in (root / 'tools/capture/library').rglob('*') if p.suffix.lower() == '.olb')
        tmp = cache.with_suffix('.tmp')
        _run(root, 'orcad_index.tcl', tmp, *libs)
        tmp.replace(cache)
    index = {}
    for line in cache.read_text(encoding='utf-8', errors='replace').splitlines():
        lib, pkg, _ = line.split('\t')
        index.setdefault(pkg.upper(), []).append(lib)
    return index


def _pick(libs):
    rank = lambda p: PREFERENCE.index(Path(p).name.lower()) if Path(p).name.lower() in PREFERENCE else len(PREFERENCE)
    return sorted(libs, key=lambda p: (rank(p), p))[0]


def resolve(component, index, root):
    """Return (library path, package, how) for one component, or raise with a precise reason."""
    explicit = component.get('orcad') or ''
    if explicit:
        lib, _, pkg = explicit.partition(':')
        path = next((p for p in index.get(pkg.upper(), []) if Path(p).name.lower() == lib.lower()), None)
        if not path:raise OperationError(f"{component['ref']}: {explicit} is not an installed Capture package.")
        return path, pkg, 'explicit'
    value = (component.get('value') or '').strip().upper()
    if value in index:
        return _pick(index[value]), value, 'part number'
    if value in SUBSTITUTES:
        lib, pkg = SUBSTITUTES[value]
        path = next((p for p in index.get(pkg.upper(), []) if Path(p).name.lower() == lib.lower()), None)
        if path:return path, pkg, f'substitute for {value} (review pinout)'
    generic = GENERIC.get(component.get('library') or '')
    if generic:
        lib, pkg = generic
        path = next((p for p in index.get(pkg.upper(), []) if Path(p).name.lower() == lib.lower()), None)
        if path:return path, pkg, 'generic symbol'
    raise OperationError(f"{component['ref']}: no Capture package for value '{component.get('value')}' "
                         f"({component.get('library')}). Set an explicit 'orcad': 'Library.olb:Package'.")


def net_aliases(graph):
    """Capture alias names: no spaces/brackets (brackets mean buses). Keeps names unique."""
    used, out = set(), {}
    for net in graph.get('nets', []):
        base = re.sub(r'[^A-Za-z0-9_+\-./]', '_', net['name'].strip()) or 'NET'
        if base[0].isdigit():base = 'N' + base
        name, i = base, 2
        while name.upper() in used:name, i = f'{base}_{i}', i + 1
        used.add(name.upper()); out[net['name']] = name
    return out


def tcl_word(text):
    """Brace-quote safely for Tcl source (balanced or escaped)."""
    text = str(text)
    if not text:return '{}'
    if re.fullmatch(r'[A-Za-z0-9_+\-./:\\]+', text) and '\\' not in text:return text
    return '"' + re.sub(r'([\\$\[\]"{}])', r'\\\1', text) + '"'


def export(name, graph, cache_dir):
    root = orcad_root()
    if root is None:
        raise OperationError('OrCAD Capture is not installed. Set ORCAD_ROOT to the OrCAD X installation folder.')
    if not graph.get('components'):
        raise OperationError('Add components before exporting an OrCAD design.')
    index = library_index(Path(cache_dir) / 'orcad-lib-index.tsv')
    aliases = net_aliases(graph)
    pin_maps = {c['ref']: GENERIC_PINS.get(c.get('library') or '', {}) for c in graph['components']
                if not c.get('orcad') and (c.get('value') or '').strip().upper() not in index}
    pin_net = {}
    for net in graph.get('nets', []):
        for node in net['nodes']:
            pin = str(node['pin'])
            key = (node['ref'], pin_maps.get(node['ref'], {}).get(pin, pin))
            if key in pin_net and pin_net[key] != aliases[net['name']]:
                raise OperationError(f"{key[0]} pin {key[1]} is on two nets.")
            pin_net[key] = aliases[net['name']]
    mapping, lines = {}, []
    for c in graph['components']:
        lib, pkg, how = resolve(c, index, root)
        mapping[c['ref']] = {'library': Path(lib).name, 'package': pkg, 'match': how, 'value': c.get('value', '')}
        pins = ' '.join(f'{tcl_word(p)} {tcl_word(n)}' for (r, p), n in sorted(pin_net.items()) if r == c['ref'])
        lines.append('{' + ' '.join([tcl_word(c['ref']), tcl_word(c.get('value', '')), tcl_word(lib), tcl_word(pkg), '{' + pins + '}']) + '}')
    safe = re.sub(r'[^A-Za-z0-9_-]', '_', name)[:60] or 'design'
    with tempfile.TemporaryDirectory() as td:
        dsn = Path(td) / f'{safe}.DSN'
        data = Path(td) / 'data.tcl'
        data.write_text(f'set design_path {tcl_word(str(dsn))}\nset components {{\n' + '\n'.join(lines) + '\n}\n', encoding='utf-8')
        _run(root, 'orcad_writer.tcl', data)
        if not dsn.is_file():raise OperationError('OrCAD Capture did not write the design file.')
        dump = _run(root, 'orcad_dump.tcl', dsn)
        report = verify(dump, pin_net, mapping)
        if not report['passed']:
            raise OperationError('OrCAD design failed reopen verification: ' + '; '.join(report['errors'][:10]))
        files = {f'{safe}.DSN': dsn.read_bytes(), 'circuit.json': json.dumps(graph, indent=2).encode(),
                 'orcad-mapping.json': json.dumps(mapping, indent=2).encode(),
                 'verification.json': json.dumps(report, indent=2).encode()}
    files['manifest.json'] = json.dumps({'format': 'OrCAD Capture native design (.DSN)', 'orcad_root': str(root),
                                         'files': {n: hashlib.sha256(v).hexdigest() for n, v in files.items()}}, indent=2).encode()
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, v in files.items():z.writestr(n, v)
    return out.getvalue(), report


def verify(dump, expected, mapping):
    """Compare the reopened design's pin/net map with the source graph."""
    actual, parts = {}, set()
    for line in dump.splitlines():
        if line.startswith(('PIN ', 'PART ')):
            words = _tcl_list(line)
            if words[0] == 'PART':parts.add(words[1])
            else:actual[(words[1], words[2])] = words[3] if len(words) > 3 else ''
    errors = []
    missing_parts = sorted(set(mapping) - parts)
    errors += [f'{r} not placed' for r in missing_parts]
    for key, net in sorted(expected.items()):
        got = actual.get(key)
        if got is None:errors.append(f'{key[0]} pin {key[1]} does not exist on {mapping[key[0]]["package"]}')
        elif got.upper() != net.upper():errors.append(f'{key[0]} pin {key[1]} on {got or "nothing"}, expected {net}')
    implicit = sorted(f'{r}.{p}={n}' for (r, p), n in actual.items() if (r, p) not in expected and n)
    return {'passed': not errors, 'errors': errors, 'components': len(parts), 'checked_pins': len(expected),
            'implicit_power_pins': implicit,
            'substitutions': {r: m for r, m in mapping.items() if m['match'].startswith('substitute')}}


def _tcl_list(line):
    """Parse one Tcl list line printed by orcad_dump.tcl (words, {braced words}, backslashes)."""
    out, i, n = [], 0, len(line)
    while i < n:
        while i < n and line[i] == ' ':i += 1
        if i >= n:break
        if line[i] == '{':
            depth, j = 1, i + 1
            while j < n and depth:
                depth += {'{': 1, '}': -1}.get(line[j], 0); j += 1
            out.append(line[i + 1:j - 1]); i = j
        else:
            j, word = i, []
            while j < n and line[j] != ' ':
                if line[j] == '\\' and j + 1 < n:word.append(line[j + 1]); j += 2
                else:word.append(line[j]); j += 1
            out.append(''.join(word)); i = j
    return out
