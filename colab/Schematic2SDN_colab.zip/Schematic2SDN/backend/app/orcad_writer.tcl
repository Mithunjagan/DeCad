# Builds a native OrCAD Capture design through Capture's own database API (orDb_Dll_Tcl64).
# Usage: tclsh orcad_writer.tcl <orDb dll> <data.tcl>
# data.tcl defines: design_path, components {{ref value olb package {pin net ...}} ...}
# Each used package section is placed; every connected pin gets a short wire stub carrying a net alias.
load [lindex $argv 0] DboTclWriteBasic
source [lindex $argv 1]

proc C {t} {return [DboTclHelper_sMakeCString $t]}
proc S {c} {return [DboTclHelper_sGetConstCharPtr $c]}
proc P {x y} {return [DboTclHelper_sMakeCPoint [expr {int($x)}] [expr {int($y)}]]}
proc fail {msg} {puts "ERROR $msg"; exit 3}

set s [DboTclHelper_sCreateSession]
set st [DboState]
set d [$s CreateDesign $st [C $design_path] [C SCHEMATIC1]]
if {$d == "NULL" || [$st Code] != 0} {fail "cannot create design"}
set sch [$d GetSchematic [C SCHEMATIC1] $st]
set pg [$sch NewPage $st [C PAGE1]]
if {$pg == "NULL"} {fail "cannot create page"}
set font [DboTclHelper_sMakeLOGFONT]
array set libs {}

proc lib_for {path} {
 global s st libs
 if {![info exists libs($path)]} {
  set lib [$s GetLib [C $path] $st]
  if {$lib == "NULL"} {fail "library not found: $path"}
  set libs($path) $lib
 }
 return $libs($path)
}

# Physical pin numbers of one package section (device).
proc device_pins {lib dev} {
 global st
 set cell [DboTclHelper_sMakeCString]; $dev GetCellName $cell
 set part [$lib GetPart [C "[S $cell].Normal"] $st]
 if {$part == "NULL"} {return [list NULL {}]}
 set it [$part NewPinsIter $st]; set n 0
 while {[$it NextPin $st] != "NULL"} {incr n}
 set pins {}
 for {set i 0} {$i < $n} {incr i} {
  set num [DboTclHelper_sMakeCString]; $dev GetPinNumber $i $num; lappend pins [S $num]
 }
 return [list $part $pins]
}

set x 200; set y 200; set rowh 0; set maxw 0
set width_limit [expr {max(3000, int(sqrt([llength $components]) * 700))}]
foreach comp $components {
 lassign $comp ref value olb pkgname pinnets
 set lib [lib_for $olb]
 set pkg [$lib GetPackage [C $pkgname] $st]
 if {$pkg == "NULL"} {fail "package $pkgname not in $olb ($ref)"}
 array unset want; array set want $pinnets
 # Choose the package sections that carry the pins this component uses.
 set sections {}
 set di [$pkg NewDevicesIter $st]; set dev [$di NextDevice $st]
 while {$dev != "NULL"} {
  lassign [device_pins $lib $dev] part pins
  set hit 0; foreach p $pins {if {[info exists want($p)]} {set hit 1}}
  if {$hit} {lappend sections [list $dev $part]}
  set dev [$di NextDevice $st]
 }
 delete_DboPackageDevicesIter $di
 if {[llength $sections] == 0} {
  # Unconnected component: still place its first section.
  set dev [$pkg GetDevice 0 $st]; lassign [device_pins $lib $dev] part pins; lappend sections [list $dev $part]
 }
 foreach sec $sections {
  lassign $sec dev part
  set inst [$pg NewPlacedInst $st [C $ref] [C $pkgname] $part $dev [P $x $y]]
  if {$inst == "NULL" || [$st Code] != 0} {fail "cannot place $ref ($pkgname)"}
  $inst SetReference [C $ref]
  if {$value ne ""} {$inst SetPartValue [C $value]}
  # Extent of the pins decides the grid cell, so stubs and labels never overlap neighbours.
  set minx 1e9; set maxx -1e9; set miny 1e9; set maxy -1e9
  set pi [$inst NewPinsIter $st]; set pin [$pi NextPin $st]; set stubs {}
  while {$pin != "NULL"} {
   set num [DboTclHelper_sMakeCString]; $pin GetPinNumber $num; set num [S $num]
   set hs [$pin GetOffsetHotSpot $st]; set so [$pin GetOffsetStartPoint $st]
   set hx [DboTclHelper_sGetCPointX $hs]; set hy [DboTclHelper_sGetCPointY $hs]
   set minx [expr {min($minx,$hx)}]; set maxx [expr {max($maxx,$hx)}]
   set miny [expr {min($miny,$hy)}]; set maxy [expr {max($maxy,$hy)}]
   if {[info exists want($num)]} {
    lappend stubs [list $num $hx $hy [expr {$hx - [DboTclHelper_sGetCPointX $so]}] [expr {$hy - [DboTclHelper_sGetCPointY $so]}]]
   }
   set pin [$pi NextPin $st]
  }
  delete_DboPartInstPinsIter $pi
  foreach stub $stubs {
   lassign $stub num hx hy dx dy
   set len [expr {max(abs($dx),abs($dy))}]; if {$len == 0} {set dx -1; set dy 0; set len 1}
   set ex [expr {$hx + 30*$dx/$len}]; set ey [expr {$hy + 30*$dy/$len}]
   set w [$pg NewWireScalar $st [P $hx $hy] [P $ex $ey]]
   if {$w == "NULL"} {fail "wire failed $ref.$num"}
   $w NewAlias $st [C $want($num)] [P $ex $ey] $font $::DboValue_NOROTATION $::DboValue_DEFAULT_OBJECT_COLOR
   puts "STUB $ref $num $want($num)"
  }
  set cw [expr {$maxx - $minx + 300}]; set chh [expr {$maxy - $miny + 200}]
  set rowh [expr {max($rowh,$chh)}]
  set x [expr {$x + $cw}]; set maxw [expr {max($maxw,$x)}]
  if {$x > $width_limit} {set x 200; set y [expr {$y + $rowh}]; set rowh 0}
 }
}
set pw [expr {(int(max($maxw, $width_limit) / 100) + 3) * 100}]
set ph [expr {(int(($y + $rowh) / 100) + 3) * 100}]
$pg SetPageSizeInfo $pw $ph 10 0
$s MarkAllLibForSave $d
set r [$s SaveDesign $d]
if {[$r Code] != 0} {fail "save failed"}
puts "SAVED $design_path page=${pw}x${ph}"
